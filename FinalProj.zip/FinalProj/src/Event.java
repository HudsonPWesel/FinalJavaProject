public class Event {
    public String eventName;

    /**
     * was planning to have interactable objects
     * 
     * @param eventName
     */
    public Event(String eventName) {
        this.eventName = eventName;

    }

}
